const express = require("express");
const mongoose = require('mongoose');

const app = express();

app.use(express.static(__dirname + "/static"));
app.use(express.urlencoded({extended: true}));

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

mongoose.connect('mongodb://localhost/Quotes', {useNewUrlParser: true});

const UserSchema = new mongoose.Schema({
  name: String,
  quote: String
 })
 const User = mongoose.model('Quotes', UserSchema);

require('./server/config/routes.js')(app)

app.listen(8000, () => console.log("listening on port 8000"));